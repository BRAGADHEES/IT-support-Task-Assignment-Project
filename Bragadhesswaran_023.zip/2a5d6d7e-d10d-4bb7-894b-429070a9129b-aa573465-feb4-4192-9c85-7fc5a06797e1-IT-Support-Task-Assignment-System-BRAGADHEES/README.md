# 2a5d6d7e-d10d-4bb7-894b-429070a9129b-aa573465-feb4-4192-9c85-7fc5a06797e1
Repository for Teams Project code and project management
