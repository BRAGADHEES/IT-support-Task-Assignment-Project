package com.examly.springapp.controller;

import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/task-assignments")
public class TaskAssignmentController {

    @GetMapping
    public String getAssignments() {
        return "Assignments";
    }
}
