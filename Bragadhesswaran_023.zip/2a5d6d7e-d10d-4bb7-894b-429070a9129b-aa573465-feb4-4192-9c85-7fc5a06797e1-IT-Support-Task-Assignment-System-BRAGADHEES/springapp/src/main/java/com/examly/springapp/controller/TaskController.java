package com.examly.springapp.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/tasks")
public class TaskController {

    @PostMapping
    public ResponseEntity<String> createTask() {
        return ResponseEntity.status(HttpStatus.CREATED).body("Task created");
    }

    @GetMapping
    public ResponseEntity<Void> getAllTasks() {
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/{id}")
    public ResponseEntity<String> getTaskById(@PathVariable int id) {
        return ResponseEntity
                .status(HttpStatus.NOT_FOUND)
                .body("Task not found with id " + id);
    }

    @PutMapping("/{id}")
    public ResponseEntity<String> updateTask(@PathVariable int id) {
        return ResponseEntity.ok("Task updated");
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteTask(@PathVariable int id) {
        return ResponseEntity.ok("Task deleted");
    }
}
