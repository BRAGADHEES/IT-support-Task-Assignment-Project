package com.examly.springapp.service;

public class TaskStatusLogServiceImpl {
    
}
