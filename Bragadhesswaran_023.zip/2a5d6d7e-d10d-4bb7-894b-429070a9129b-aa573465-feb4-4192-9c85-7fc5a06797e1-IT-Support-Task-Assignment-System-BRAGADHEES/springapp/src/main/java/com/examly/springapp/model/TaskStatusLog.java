package com.examly.springapp.model;

import jakarta.persistence.*;

@Entity
public class TaskStatusLog {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
}
