package com.examly.springapp.controller;

import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/task-status-logs")
public class TaskStatusLogController {
}
